﻿using System;
using System.Drawing;
using System.IO;
using System.Windows;

namespace WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        uint lengthL = 0, repeatsAmount = 0, intersectionAmount;


        private void MainWindowView_Loaded(object sender, RoutedEventArgs e)
        {
            input_L.Text = input_N.Text = input_I.Text = "0";
        }

        private void Button_Calculate_Click(object sender, RoutedEventArgs e)
        {
            //if (File.Exists("./Result"))
            //{
            //    new FileInfo("./Result").Delete();
            //}


            int I, N, L;

            try
            {
                I = Convert.ToInt32(input_I.Text);
                N = Convert.ToInt32(input_N.Text);
                L = Convert.ToInt32(input_L.Text);
            }
            catch
            {
                MessageBox.Show("Invalid input params");
                return;
            }


            Bitmap bmp = CreateBitmap(L, I);

            if (bmp != null)
            {
                bmp.Save("Result.bmp");
                MainView.UpdateLayout();
            }
        }

        public Bitmap CreateBitmap(int lengthL, int intersectionAmount)
        {
            Bitmap bmp;

            try
            {
                bmp = new Bitmap(lengthL * 2, (lengthL * (intersectionAmount + 1)) + 1 * intersectionAmount);
            }
            catch
            {
                return null;
            }

            FillBitmap(ref bmp, Color.White);

            if (intersectionAmount == 0)
            {
                return bmp;
            }

            DrawLine(ref bmp, new System.Drawing.Point(0, lengthL + 1), new System.Drawing.Point(bmp.Width, lengthL + 1), Color.Black);

            for (int i = 1; i < intersectionAmount; i++)
            {
                DrawLine(ref bmp, new System.Drawing.Point(0, lengthL * (i + 1) + 1), new System.Drawing.Point(bmp.Width, lengthL * (i + 1) + 1), Color.Black);
            }

            return bmp;
        }


        /// <summary>
        /// Paint full bitmap with one color
        /// </summary>
        public void FillBitmap(ref Bitmap bmp, Color emptyPixelColor)
        {
            for (int i = 0; i < bmp.Height; i++)
            {
                for (int j = 0; j < bmp.Width; j++)
                {
                    bmp.SetPixel(j, i, emptyPixelColor);
                }
            }
        }

        public void DrawLine(ref Bitmap bmp, System.Drawing.Point p1, System.Drawing.Point p2, Color lineColor)
        {
            double x1 = (double)p1.X;
            double y1 = (double)p1.Y;

            double x2 = (double)p2.X;
            double y2 = (double)p2.Y;

            if (Math.Abs(x2 - x1) >= Math.Abs(y2 - y1))
            {
                if (x2 - x1 == 0)
                {
                    return;
                }

                if (x2 < x1)
                {
                    Swap(ref x1, ref x2);
                    Swap(ref y1, ref y2);
                }

                double k = (y2 - y1) / (x2 - x1);

                double y = y1;

                for (double x = x1; x < x2; x++)
                {
                    bmp.SetPixel((int)x, (int)y, lineColor);
                    y += k;
                }
            }
            else
            {
                if (y2 - y1 == 0)
                {
                    return;
                }



                if (y2 < y1)
                {
                    Swap(ref x1, ref x2);
                    Swap(ref y1, ref y2);
                }

                double k = (x2 - x1) / (y2 - y1);

                double x = x1;

                for (int y = (int)y1; y < (int)y2; y++)
                {
                    bmp.SetPixel((int)x, (int)y, lineColor);
                    x += k;
                }

            }
        }

        /// <summary>
        /// Swap two double values between each other
        /// </summary>
        public void Swap(ref double item1, ref double item2)
        {
            double buffer = item1;
            item1 = item2;
            item2 = buffer;
        }

    }
}
